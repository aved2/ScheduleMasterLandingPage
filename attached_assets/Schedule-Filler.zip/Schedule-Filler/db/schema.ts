import { pgTable, text, serial, integer, boolean, timestamp, jsonb, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").unique().notNull(),
  name: text("name").notNull(),
  preferences: jsonb("preferences").notNull().default({})
});

export const calendarConnections = pgTable("calendarConnections", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  provider: text("provider").notNull(),
  accessToken: text("access_token").notNull(),
  refreshToken: text("refresh_token"),
  calendarId: text("calendar_id").notNull(),
  color: text("color").notNull(),
  syncEnabled: boolean("sync_enabled").default(false),
  lastSynced: timestamp("last_synced")
});

export const sharedEvents = pgTable("shared_events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time").notNull(),
  location: text("location"),
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at"),
  status: text("status").notNull(),
  importanceScore: decimal("importance_score").default('0'),
  priorityScore: decimal("priority_score").default('0'),
  lastScored: timestamp("last_scored"),
  scoringMetadata: jsonb("scoring_metadata").default({})
});

export const eventParticipants = pgTable("event_participants", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id").references(() => sharedEvents.id),
  userId: integer("user_id").references(() => users.id),
  status: text("status").notNull(),
  responseTime: timestamp("response_time"),
  notes: text("notes")
});

// Type definitions
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type CalendarConnection = typeof calendarConnections.$inferSelect;
export type InsertCalendarConnection = typeof calendarConnections.$inferInsert;
export type SharedEvent = typeof sharedEvents.$inferSelect;
export type InsertSharedEvent = typeof sharedEvents.$inferInsert;
export type EventParticipant = typeof eventParticipants.$inferSelect;
export type InsertEventParticipant = typeof eventParticipants.$inferInsert;

// Schema validations
export const insertUserSchema = createInsertSchema(users);
export const selectUserSchema = createSelectSchema(users);
export const insertCalendarConnectionSchema = createInsertSchema(calendarConnections);
export const selectCalendarConnectionSchema = createSelectSchema(calendarConnections);
export const insertSharedEventSchema = createInsertSchema(sharedEvents);
export const selectSharedEventSchema = createSelectSchema(sharedEvents);
export const insertEventParticipantSchema = createInsertSchema(eventParticipants);
export const selectEventParticipantSchema = createSelectSchema(eventParticipants);