import { drizzle } from "drizzle-orm/neon-http";
import { neon, neonConfig } from '@neondatabase/serverless';
import * as schema from "./schema";
import ws from 'ws';

// Required for Neon serverless with WebSocket pooling
neonConfig.webSocketConstructor = ws;
const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
  throw new Error("DATABASE_URL environment variable is not set");
}

const sql = neon(connectionString);
export const db = drizzle(sql, { schema });