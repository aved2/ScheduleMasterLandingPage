# ActivitySync - Smart Calendar Platform

A smart multi-calendar platform designed to help users discover, plan, and share activities through intelligent recommendations and seamless calendar integration.

## Project Structure

```
├── client/
│   └── src/
│       ├── components/
│       │   ├── activities/
│       │   │   ├── recommendation-card.tsx    # Displays activity recommendations
│       │   │   └── activity-list.tsx          # Lists suggested activities
│       │   ├── calendar/
│       │   │   ├── calendar-integration.tsx   # Google Calendar OAuth integration
│       │   │   └── unified-calendar.tsx       # Combined calendar view
│       │   └── layout/
│       │       └── navbar.tsx                 # Main navigation
│       ├── pages/
│       │   ├── dashboard.tsx                  # Main calendar and recommendations view
│       │   └── settings.tsx                   # Calendar connection management
│       └── lib/
│           └── queryClient.ts                 # API query configuration
├── server/
│   ├── services/
│   │   ├── calendar-service.ts               # Google Calendar API integration
│   │   ├── yelp-service.ts                   # Yelp API integration
│   │   └── weather-service.ts                # Weather service (optional)
│   └── routes.ts                             # API endpoints
```

## Key Features

### 1. Calendar Integration

```typescript
// server/services/calendar-service.ts
export async function fetchCalendarEvents(connection: CalendarConnection, timeMin: Date, timeMax: Date): Promise<Event[]> {
  if (connection.provider !== 'google') {
    throw new Error('Only Google Calendar is supported');
  }

  const calendar = createGoogleClient(connection);
  const response = await calendar.events.list({
    calendarId: connection.calendarId,
    timeMin: timeMin.toISOString(),
    timeMax: timeMax.toISOString(),
    singleEvents: true,
    orderBy: 'startTime',
  });

  return (response.data.items || []).map(event => ({
    id: event.id!,
    title: event.summary || 'Untitled Event',
    start: new Date(event.start?.dateTime || event.start?.date!),
    end: new Date(event.end?.dateTime || event.end?.date!),
    calendarId: connection.calendarId,
    location: event.location
  }));
}
```

### 2. Activity Recommendations

```typescript
// server/services/yelp-service.ts
export async function getRecommendationsBetweenEvents(
  location: string,
  startTime: Date,
  endTime: Date,
  options: {
    radius?: number;
    maxResults?: number;
    categories?: string[];
    includeRestaurants?: boolean;
  } = {}
): Promise<{
  restaurants: YelpBusiness[];
  activities: YelpBusiness[];
}> {
  const timeAvailable = (endTime.getTime() - startTime.getTime()) / (1000 * 60);
  
  const baseParams: Partial<YelpSearchParams> = {
    location,
    radius: options.radius || 1000,
    limit: options.maxResults || 5,
    open_at: Math.floor(startTime.getTime() / 1000),
    sort_by: 'rating'
  };

  // Quick food options for short breaks
  if (timeAvailable < 45) {
    const restaurants = await searchYelp({
      ...baseParams,
      categories: 'quickfood,sandwiches,cafes',
    });
    return { restaurants, activities: [] };
  }

  // Both restaurants and activities for longer breaks
  const [restaurants, activities] = await Promise.all([
    options.includeRestaurants !== false ? searchYelp({
      ...baseParams,
      categories: 'restaurants',
    }) : Promise.resolve([]),
    searchYelp({
      ...baseParams,
      categories: options.categories?.join(',') || 'arts,entertainment,active',
    })
  ]);

  return {
    restaurants,
    activities: activities.filter(activity => {
      const timeIntensiveCategories = ['museums', 'theaters'];
      if (timeAvailable < 90 && activity.categories.some(cat => 
        timeIntensiveCategories.includes(cat.alias)
      )) {
        return false;
      }
      return true;
    })
  };
}
```

## API Endpoints

### Calendar Integration

- `GET /api/auth/google` - Start Google OAuth flow
- `GET /api/auth/google/callback` - OAuth callback handler
- `GET /api/calendar-connections` - List connected calendars

### Activity Recommendations

- `GET /api/recommendations/between` - Get recommendations between events
  ```typescript
  // Example request:
  GET /api/recommendations/between?
    location=Golden%20Gate%20Park,%20San%20Francisco&
    start=2025-01-25T11:00:00&
    end=2025-01-25T13:00:00
  ```

- `GET /api/activities/suggestions` - Get personalized activity suggestions
- `POST /api/activities/preferences` - Update activity preferences

## Frontend Components

### Calendar Integration UI

```typescript
// client/src/components/calendar/calendar-integration.tsx
export default function CalendarIntegration() {
  const handleGoogleAuth = () => {
    const width = 600;
    const height = 700;
    const left = window.screenX + (window.outerWidth - width) / 2;
    const top = window.screenY + (window.outerHeight - height) / 2;

    const authWindow = window.open(
      '/api/auth/google',
      'Google Calendar Authorization',
      `width=${width},height=${height},left=${left},top=${top}`
    );
  };

  return (
    <Button
      size="lg"
      className="flex items-center gap-3"
      onClick={handleGoogleAuth}
    >
      <SiGoogle className="h-5 w-5" />
      Connect Google Calendar
    </Button>
  );
}
```

### Activity Recommendations Display

```typescript
// client/src/components/activities/recommendation-card.tsx
export default function RecommendationCard({ recommendation }: RecommendationCardProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>
          Recommendations for {recommendation.eventTitle}
        </CardTitle>
        <div className="flex items-center gap-2">
          <Clock className="h-4 w-4" />
          {format(new Date(recommendation.eventStart), 'MMM d, h:mm a')}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Restaurants Section */}
          <div>
            <h3>Nearby Restaurants</h3>
            {recommendation.recommendations.restaurants.map((restaurant) => (
              // Restaurant card
            ))}
          </div>
          {/* Activities Section */}
          <div>
            <h3>Nearby Activities</h3>
            {recommendation.recommendations.activities.map((activity) => (
              // Activity card
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
```

## Environment Variables Required

- `GOOGLE_CLIENT_ID` - Google OAuth client ID
- `GOOGLE_CLIENT_SECRET` - Google OAuth client secret
- `YELP_API_KEY` - Yelp Fusion API key
- `DATABASE_URL` - PostgreSQL database URL

## Getting Started

1. Install dependencies:
```bash
npm install
```

2. Set up environment variables in `.env`

3. Start the development server:
```bash
npm run dev
```

The application will be available at `http://localhost:5000`.
