
import express from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";

function setupMiddleware(app: express.Express) {
  app.use(express.json());
  app.use(express.urlencoded({ extended: false }));

  // Request logging middleware
  app.use((req, res, next) => {
    const start = Date.now();
    const path = req.path;
    let responseBody: Record<string, any> | undefined;

    const originalJson = res.json;
    res.json = function (body, ...args) {
      responseBody = body;
      return originalJson.apply(res, [body, ...args]);
    };

    res.on("finish", () => {
      if (path.startsWith("/api")) {
        const duration = Date.now() - start;
        let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
        
        if (responseBody) {
          const bodyStr = JSON.stringify(responseBody);
          logLine += bodyStr.length > 50 ? ` :: ${bodyStr.slice(0, 49)}…` : ` :: ${bodyStr}`;
        }
        
        log(logLine);
      }
    });

    next();
  });
}

async function startServer() {
  // Validate required environment variables
  const requiredEnvVars = [
    'GOOGLE_CLIENT_ID',
    'GOOGLE_CLIENT_SECRET',
    'YELP_API_KEY',
    'DATABASE_URL'
  ];
  
  const missingEnvVars = requiredEnvVars.filter(envVar => !process.env[envVar]);
  if (missingEnvVars.length > 0) {
    console.error(`Missing required environment variables: ${missingEnvVars.join(', ')}`);
    process.exit(1);
  }

  const app = express();
  setupMiddleware(app);

  const server = registerRoutes(app);

  // Error handling middleware
  app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    throw err;
  });

  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const PORT = 5000;
  server.listen(PORT, "0.0.0.0", () => {
    log(`Server running on port ${PORT}`);
  });
}

startServer().catch(console.error);
