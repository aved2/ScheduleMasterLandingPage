import type { Express } from "express";
import { createServer, type Server } from "http";
import cors from 'cors';
import type { CorsOptions } from 'cors';
import { google } from 'googleapis';
import { db } from "@db";
import { calendarConnections, sharedEvents, eventParticipants, users } from "@db/schema";
import { eq, and, gt, lt } from "drizzle-orm";
import { fetchCalendarEvents, addEventToCalendar } from "./services/calendar-service";
import { EventScoringService } from "./services/event-scoring-service";

// Get the stable Replit URL for OAuth redirect
const BASE_URL = "https://workspace.ankithmareddy.repl.co";

console.log('Current BASE_URL:', BASE_URL); // For debugging

const corsOptions: CorsOptions = {
  origin: BASE_URL,
  credentials: true,
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
};

export function registerRoutes(app: Express): Server {
  app.use(cors(corsOptions));

  // Google Calendar Auth Routes
  app.get("/api/auth/google/calendar", (req, res) => {
    try {
      const oauth2Client = new google.auth.OAuth2(
        process.env.GOOGLE_CLIENT_ID,
        process.env.GOOGLE_CLIENT_SECRET,
        `${BASE_URL}/api/auth/google/callback/`
      );

      const authUrl = oauth2Client.generateAuthUrl({
        access_type: 'offline',
        scope: [
          'https://www.googleapis.com/auth/calendar.readonly',
          'https://www.googleapis.com/auth/calendar.events'
        ],
        prompt: 'consent'
      });

      console.log('Generated auth URL:', authUrl); // For debugging
      res.redirect(authUrl);
    } catch (error) {
      console.error('Failed to generate Google auth URL:', error);
      res.redirect('/?calendar=error');
    }
  });

  app.get("/api/auth/google/callback", async (req, res) => {
    try {
      const { code, error } = req.query;

      if (error) {
        console.error('OAuth error:', error);
        return res.redirect('/?calendar=error');
      }

      if (!code || typeof code !== 'string') {
        console.error('Missing authorization code in callback');
        return res.redirect('/?calendar=error');
      }

      const oauth2Client = new google.auth.OAuth2(
        process.env.GOOGLE_CLIENT_ID,
        process.env.GOOGLE_CLIENT_SECRET,
        `${BASE_URL}/api/auth/google/callback/`
      );

      const { tokens } = await oauth2Client.getToken(code);
      oauth2Client.setCredentials(tokens);

      await db.insert(calendarConnections).values({
        provider: 'google',
        accessToken: tokens.access_token!,
        refreshToken: tokens.refresh_token!,
        calendarId: 'primary',
        userId: 1, // TODO: Get actual user ID from session
        color: '#4285f4'
      });

      res.redirect('/?calendar=connected');
    } catch (error) {
      console.error('OAuth callback error:', error);
      res.redirect('/?calendar=error');
    }
  });

  // Calendar Data Routes
  app.get("/api/calendar-connections", async (req, res) => {
    try {
      const connections = await db.query.calendarConnections.findMany({
        where: eq(calendarConnections.userId, 1)
      });
      res.json(connections);
    } catch (error) {
      console.error('Failed to fetch calendar connections:', error);
      res.status(500).json({ error: "Failed to fetch calendar connections" });
    }
  });

  // Event Management Routes
  app.post("/api/events", async (req, res) => {
    try {
      const { title, description, startTime, endTime, location } = req.body;
      const userId = 1; // TODO: Get from session

      const newEvent = await db.insert(sharedEvents).values({
        title,
        description,
        startTime: new Date(startTime),
        endTime: new Date(endTime),
        location,
        createdBy: userId,
        status: 'pending',
      }).returning();

      await EventScoringService.updateEventScores(newEvent[0].id);

      await db.insert(eventParticipants).values({
        eventId: newEvent[0].id,
        userId,
        status: 'accepted',
      });

      const eventWithScores = await db.query.sharedEvents.findFirst({
        where: eq(sharedEvents.id, newEvent[0].id)
      });

      res.json(eventWithScores);
    } catch (error) {
      console.error('Failed to create event:', error);
      res.status(500).json({ error: "Failed to create event" });
    }
  });

  // Event Scoring and Conflict Routes
  app.get("/api/events/:eventId/conflicts", async (req, res) => {
    try {
      const { eventId } = req.params;
      const event = await db.query.sharedEvents.findFirst({
        where: eq(sharedEvents.id, parseInt(eventId))
      });

      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }

      const userId = 1; // TODO: Get from session
      const conflicts = await EventScoringService.findConflicts(event, userId);

      const conflictDetails = conflicts.map(conflict => ({
        event: conflict,
        overlapPercentage: EventScoringService.calculateOverlap(event, conflict)
      }));

      res.json({
        conflicts: conflictDetails,
        suggestedTimes: await EventScoringService.suggestAlternativeTimes(event, userId)
      });
    } catch (error) {
      console.error('Failed to check conflicts:', error);
      res.status(500).json({ error: "Failed to check conflicts" });
    }
  });

  app.post("/api/events/:eventId/reschedule", async (req, res) => {
    try {
      const { eventId } = req.params;
      const { newStartTime } = req.body;
      const userId = 1; // TODO: Get from session

      const event = await db.query.sharedEvents.findFirst({
        where: eq(sharedEvents.id, parseInt(eventId))
      });

      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }

      const originalDuration = new Date(event.endTime).getTime() - new Date(event.startTime).getTime();
      const newEndTime = new Date(new Date(newStartTime).getTime() + originalDuration);

      const updatedEvent = await db.update(sharedEvents)
        .set({
          startTime: new Date(newStartTime),
          endTime: newEndTime,
          updatedAt: new Date()
        })
        .where(eq(sharedEvents.id, parseInt(eventId)))
        .returning();

      await EventScoringService.updateEventScores(parseInt(eventId));

      res.json(updatedEvent[0]);
    } catch (error) {
      console.error('Failed to reschedule event:', error);
      res.status(500).json({ error: "Failed to reschedule event" });
    }
  });

  app.get("/api/events/:eventId/scores", async (req, res) => {
    try {
      const { eventId } = req.params;
      const event = await db.query.sharedEvents.findFirst({
        where: eq(sharedEvents.id, parseInt(eventId))
      });

      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }

      await EventScoringService.updateEventScores(parseInt(eventId));

      const updatedEvent = await db.query.sharedEvents.findFirst({
        where: eq(sharedEvents.id, parseInt(eventId))
      });

      res.json({
        importanceScore: updatedEvent?.importanceScore,
        priorityScore: updatedEvent?.priorityScore,
        lastScored: updatedEvent?.lastScored,
        scoringMetadata: updatedEvent?.scoringMetadata
      });
    } catch (error) {
      console.error('Failed to get event scores:', error);
      res.status(500).json({ error: "Failed to get event scores" });
    }
  });


  const httpServer = createServer(app);
  return httpServer;
}