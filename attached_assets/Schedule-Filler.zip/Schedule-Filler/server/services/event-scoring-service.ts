import { type SharedEvent, type EventScoringFactor } from "@db/schema";
import { db } from "@db";
import { eq, and, gt, lt } from "drizzle-orm";
import { sharedEvents } from "@db/schema";

interface ScoringContext {
  userRole?: string;
  userPreferences?: Record<string, any>;
  historicalAttendance?: number;
  conflictCount?: number;
  conflicts?: Array<{
    eventId: number;
    overlapPercentage: number;
    priority: number;
  }>;
}

export class EventScoringService {
  private static readonly DECAY_FACTOR = 0.85; // Time decay factor
  private static readonly MIN_SCORE = 0;
  private static readonly MAX_SCORE = 100;
  private static readonly OVERLAP_THRESHOLD = 0.25; // 25% overlap is considered a conflict

  /**
   * Check for conflicts with existing events
   */
  static async findConflicts(event: SharedEvent, userId: number): Promise<Array<SharedEvent>> {
    const eventStart = new Date(event.startTime);
    const eventEnd = new Date(event.endTime);

    const conflicts = await db.query.sharedEvents.findMany({
      where: and(
        eq(sharedEvents.createdBy, userId),
        gt(sharedEvents.endTime, eventStart),
        lt(sharedEvents.startTime, eventEnd),
        event.id ? gt(sharedEvents.id, event.id) : undefined
      ),
    });

    return conflicts;
  }

  /**
   * Calculate the overlap percentage between two events
   */
  static calculateOverlap(event1: SharedEvent, event2: SharedEvent): number {
    const start1 = new Date(event1.startTime).getTime();
    const end1 = new Date(event1.endTime).getTime();
    const start2 = new Date(event2.startTime).getTime();
    const end2 = new Date(event2.endTime).getTime();

    const overlapStart = Math.max(start1, start2);
    const overlapEnd = Math.min(end1, end2);

    if (overlapEnd <= overlapStart) return 0;

    const overlap = overlapEnd - overlapStart;
    const duration1 = end1 - start1;

    return overlap / duration1;
  }

  /**
   * Suggest alternative times for an event based on conflicts
   */
  static async suggestAlternativeTimes(
    event: SharedEvent,
    userId: number,
    windowHours: number = 24
  ): Promise<Date[]> {
    const eventDuration = new Date(event.endTime).getTime() - new Date(event.startTime).getTime();
    const windowStart = new Date(event.startTime);
    const windowEnd = new Date(windowStart.getTime() + windowHours * 60 * 60 * 1000);

    // Get all events in the time window
    const existingEvents = await db.query.sharedEvents.findMany({
      where: and(
        eq(sharedEvents.createdBy, userId),
        gt(sharedEvents.endTime, windowStart),
        lt(sharedEvents.startTime, windowEnd)
      ),
    });

    // Find free time slots
    const suggestions: Date[] = [];
    let currentTime = windowStart;

    while (currentTime < windowEnd && suggestions.length < 3) {
      let canSchedule = true;
      const potentialEnd = new Date(currentTime.getTime() + eventDuration);

      for (const existing of existingEvents) {
        const existingStart = new Date(existing.startTime);
        const existingEnd = new Date(existing.endTime);

        if (
          (currentTime >= existingStart && currentTime < existingEnd) ||
          (potentialEnd > existingStart && potentialEnd <= existingEnd)
        ) {
          canSchedule = false;
          // Jump to the end of this event
          currentTime = new Date(existingEnd);
          break;
        }
      }

      if (canSchedule) {
        suggestions.push(new Date(currentTime));
        // Move to next hour
        currentTime = new Date(currentTime.getTime() + 60 * 60 * 1000);
      } else {
        currentTime = new Date(currentTime.getTime() + 30 * 60 * 1000); // 30-minute increments
      }
    }

    return suggestions;
  }

  /**
   * Calculate importance score based on multiple factors
   */
  static async calculateImportanceScore(
    event: SharedEvent,
    context: ScoringContext
  ): Promise<number> {
    const scores: number[] = [];
    const weights: number[] = [];

    // Attendee importance (20%)
    const attendeeScore = this.calculateAttendeeScore(event, context);
    scores.push(attendeeScore);
    weights.push(0.20);

    // Time sensitivity (25%)
    const timeScore = this.calculateTimeScore(event);
    scores.push(timeScore);
    weights.push(0.25);

    // Meeting purpose/type (20%)
    const purposeScore = this.calculatePurposeScore(event);
    scores.push(purposeScore);
    weights.push(0.20);

    // Historical patterns (15%)
    const historyScore = this.calculateHistoryScore(context);
    scores.push(historyScore);
    weights.push(0.15);

    // Calendar conflicts (20%)
    const conflictScore = this.calculateConflictScore(context);
    scores.push(conflictScore);
    weights.push(0.20);

    // Calculate weighted average
    const weightedScore = scores.reduce((acc, score, index) => {
      return acc + score * weights[index];
    }, 0);

    return Math.min(Math.max(weightedScore, this.MIN_SCORE), this.MAX_SCORE);
  }

  /**
   * Calculate priority score based on importance and urgency
   */
  static async calculatePriorityScore(
    event: SharedEvent,
    importanceScore: number
  ): Promise<number> {
    const now = new Date();
    const eventStart = new Date(event.startTime);
    const timeUntilEvent = eventStart.getTime() - now.getTime();
    const daysUntilEvent = timeUntilEvent / (1000 * 60 * 60 * 24);

    // Exponential decay based on time until event
    const urgencyFactor = Math.exp(-daysUntilEvent * this.DECAY_FACTOR);

    // Priority combines importance and urgency
    const priorityScore = importanceScore * urgencyFactor;

    return Math.min(Math.max(priorityScore, this.MIN_SCORE), this.MAX_SCORE);
  }

  private static calculateAttendeeScore(
    event: SharedEvent,
    context: ScoringContext
  ): number {
    return 75; // Placeholder score
  }

  private static calculateTimeScore(event: SharedEvent): number {
    return 80; // Placeholder score
  }

  private static calculatePurposeScore(event: SharedEvent): number {
    return 70; // Placeholder score
  }

  private static calculateHistoryScore(context: ScoringContext): number {
    return context.historicalAttendance || 65;
  }

  private static calculateConflictScore(context: ScoringContext): number {
    if (!context.conflicts) return 100;

    // Calculate conflict penalty based on overlap percentage and conflicting event priority
    const totalPenalty = context.conflicts.reduce((acc, conflict) => {
      return acc + (conflict.overlapPercentage * conflict.priority / 100);
    }, 0);

    return Math.max(0, 100 - totalPenalty * 20); // More severe penalty for high-priority conflicts
  }

  /**
   * Update event scores in the database
   */
  static async updateEventScores(eventId: number): Promise<void> {
    const event = await db.query.sharedEvents.findFirst({
      where: eq(sharedEvents.id, eventId)
    });

    if (!event) return;

    // Find conflicts
    const conflicts = await this.findConflicts(event, event.createdBy || 1);
    const conflictDetails = await Promise.all(
      conflicts.map(async (conflict) => ({
        eventId: conflict.id,
        overlapPercentage: this.calculateOverlap(event, conflict),
        priority: conflict.priorityScore || 0
      }))
    );

    const context: ScoringContext = {
      historicalAttendance: 0.8,
      conflictCount: conflicts.length,
      conflicts: conflictDetails
    };

    const importanceScore = await this.calculateImportanceScore(event, context);
    const priorityScore = await this.calculatePriorityScore(event, importanceScore);

    await db.update(sharedEvents)
      .set({
        importanceScore,
        priorityScore,
        lastScored: new Date(),
        scoringMetadata: {
          lastCalculation: new Date(),
          conflicts: conflictDetails,
          factors: {
            attendeeScore: this.calculateAttendeeScore(event, context),
            timeScore: this.calculateTimeScore(event),
            purposeScore: this.calculatePurposeScore(event),
            historyScore: this.calculateHistoryScore(context),
            conflictScore: this.calculateConflictScore(context)
          }
        }
      })
      .where(eq(sharedEvents.id, eventId));
  }
}