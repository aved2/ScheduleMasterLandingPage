import type { CalendarEvent } from "../../client/src/lib/calendar-utils";
import { getWeatherForecast } from "./weather-service";

interface YelpBusiness {
  id: string;
  name: string;
  url: string;
  rating: number;
  price?: string;
  categories: Array<{ alias: string; title: string }>;
  location: {
    address1: string;
    city: string;
    state: string;
    country: string;
  };
  coordinates: {
    latitude: number;
    longitude: number;
  };
}

interface YelpSearchParams {
  term?: string;
  categories?: string;
  location: string;
  radius?: number; // meters
  price?: string; // 1,2,3,4 comma delimited
  open_at?: number; // unix timestamp
  limit?: number;
  sort_by?: 'best_match' | 'rating' | 'review_count' | 'distance';
}

// Map budget preferences to Yelp price levels (this function remains unchanged)
function getBudgetPriceRange(budget: 'low' | 'medium' | 'high'): string {
  switch (budget) {
    case 'low':
      return '1,2';
    case 'medium':
      return '2,3';
    case 'high':
      return '3,4';
    default:
      return '1,2,3,4';
  }
}

// Get weather-appropriate activities (this function remains unchanged)
function getWeatherAppropriateCategories(weather: { temp: number; condition: string }) {
  const categories = [];
  const isGoodWeather = !weather.condition.toLowerCase().includes('rain') &&
    !weather.condition.toLowerCase().includes('snow') &&
    weather.temp >= 15; // 15°C / 59°F

  if (isGoodWeather) {
    categories.push(
      'hiking',
      'parks',
      'beaches',
      'biking',
      'outdoor_sports'
    );
  } else {
    categories.push(
      'museums',
      'galleries',
      'bowling',
      'cinema',
      'indoor_sports'
    );
  }

  return categories.join(',');
}

async function searchYelp(params: YelpSearchParams): Promise<YelpBusiness[]> {
  const searchParams = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined) {
      searchParams.append(key, value.toString());
    }
  });

  const response = await fetch(
    `https://api.yelp.com/v3/businesses/search?${searchParams.toString()}`,
    {
      headers: {
        Authorization: `Bearer ${process.env.YELP_API_KEY}`,
        Accept: "application/json",
      },
    }
  );

  if (!response.ok) {
    throw new Error(`Yelp API error: ${response.statusText}`);
  }

  const data = await response.json();
  return data.businesses;
}

// Get recommendations for time between events
export async function getRecommendationsBetweenEvents(
  location: string,
  startTime: Date,
  endTime: Date,
  options: {
    radius?: number; // meters
    maxResults?: number;
    categories?: string[];
    includeRestaurants?: boolean;
  } = {}
): Promise<{
  restaurants: YelpBusiness[];
  activities: YelpBusiness[];
}> {
  const timeAvailable = (endTime.getTime() - startTime.getTime()) / (1000 * 60); // in minutes
  console.log(`Time available between events: ${timeAvailable} minutes at ${location}`);

  const baseParams: Partial<YelpSearchParams> = {
    location,
    radius: options.radius || 1000, // Default 1km
    limit: options.maxResults || 5,
    open_at: Math.floor(startTime.getTime() / 1000),
    sort_by: 'rating'
  };

  // If we have less than 45 minutes, only suggest quick food options
  if (timeAvailable < 45) {
    const restaurants = await searchYelp({
      ...baseParams,
      categories: 'quickfood,sandwiches,cafes',
    });
    return { restaurants, activities: [] };
  }

  // For longer breaks, get both restaurants and activities
  const [restaurants, activities] = await Promise.all([
    options.includeRestaurants !== false ? searchYelp({
      ...baseParams,
      categories: 'restaurants',
    }) : Promise.resolve([]),
    searchYelp({
      ...baseParams,
      categories: options.categories?.join(',') || 'arts,entertainment,active',
    })
  ]);

  return {
    restaurants,
    activities: activities.filter(activity => {
      // Filter out activities that might take too long
      const timeIntensiveCategories = ['museums', 'theaters'];
      if (timeAvailable < 90 && activity.categories.some(cat => 
        timeIntensiveCategories.includes(cat.alias)
      )) {
        return false;
      }
      return true;
    })
  };
}

// Simplified getRecommendationsNearEvent function
export async function getRecommendationsNearEvent(
  event: CalendarEvent,
  category: "restaurants" | "activities",
  options: {
    timeBuffer?: number // minutes
  } = {}
): Promise<YelpBusiness[]> {
  if (!event.location) {
    return [];
  }

  const params: YelpSearchParams = {
    location: event.location,
    radius: 1000,
    limit: 5,
    sort_by: 'rating'
  };

  if (category === "restaurants") {
    params.categories = 'restaurants';
    params.open_at = Math.floor(event.start.getTime() / 1000);
  } else {
    params.categories = 'arts,entertainment,active';
    params.open_at = Math.floor(
      (event.end.getTime() + (options.timeBuffer || 60) * 60 * 1000) / 1000
    );
  }

  try {
    const results = await searchYelp(params);
    console.log(`Found ${results.length} ${category} recommendations for event`, {
      eventId: event.id,
      location: event.location,
      categories: params.categories
    });
    return results;
  } catch (error) {
    console.error('Failed to get recommendations:', error);
    return [];
  }
}