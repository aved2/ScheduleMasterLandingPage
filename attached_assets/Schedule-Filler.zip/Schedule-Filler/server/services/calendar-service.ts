import { google } from 'googleapis';
import type { CalendarConnection, User } from "@db/schema";
import { db } from "@db/index";
import { eq } from "drizzle-orm";

interface Event {
  id: string;
  title: string;
  start: Date;
  end: Date;
  calendarId: string;
  location?: string;
  type?: 'work' | 'social' | 'personal';
  description?: string;
  recurrence?: string[];
}

interface CalendarProvider {
  fetchEvents(connection: CalendarConnection, timeMin: Date, timeMax: Date): Promise<Event[]>;
  addEvent(connection: CalendarConnection, event: Omit<Event, 'id'>): Promise<Event>;
}

// Google Calendar Provider
class GoogleCalendarProvider implements CalendarProvider {
  private async createClient(connection: CalendarConnection) {
    const BASE_URL = "https://schedule-filler-ankithmareddy.replit.app";

    const oauth2Client = new google.auth.OAuth2(
      process.env.GOOGLE_CLIENT_ID,
      process.env.GOOGLE_CLIENT_SECRET,
      `${BASE_URL}/api/auth/google/callback/`
    );

    oauth2Client.setCredentials({
      access_token: connection.accessToken,
      refresh_token: connection.refreshToken
    });

    return google.calendar({ version: 'v3', auth: oauth2Client });
  }

  async fetchEvents(connection: CalendarConnection, timeMin: Date, timeMax: Date): Promise<Event[]> {
    const calendar = await this.createClient(connection);
    const response = await calendar.events.list({
      calendarId: connection.calendarId,
      timeMin: timeMin.toISOString(),
      timeMax: timeMax.toISOString(),
      singleEvents: true,
      orderBy: 'startTime',
    });

    return (response.data.items || []).map(event => ({
      id: event.id!,
      title: event.summary || 'Untitled Event',
      start: new Date(event.start?.dateTime || event.start?.date!),
      end: new Date(event.end?.dateTime || event.end?.date!),
      calendarId: connection.calendarId,
      location: event.location,
      description: event.description,
      type: detectEventType(event),
      recurrence: event.recurrence
    }));
  }

  async addEvent(connection: CalendarConnection, event: Omit<Event, 'id'>): Promise<Event> {
    const calendar = await this.createClient(connection);
    const response = await calendar.events.insert({
      calendarId: connection.calendarId,
      requestBody: {
        summary: event.title,
        location: event.location,
        description: event.description,
        start: {
          dateTime: event.start.toISOString(),
        },
        end: {
          dateTime: event.end.toISOString(),
        }
      }
    });

    return {
      id: response.data.id!,
      title: response.data.summary!,
      start: new Date(response.data.start?.dateTime!),
      end: new Date(response.data.end?.dateTime!),
      calendarId: connection.calendarId,
      location: response.data.location,
      type: detectEventType(response.data)
    };
  }
}

// Apple Calendar Provider (Mock Implementation)
class AppleCalendarProvider implements CalendarProvider {
  async fetchEvents(connection: CalendarConnection, timeMin: Date, timeMax: Date): Promise<Event[]> {
    // Mock implementation - replace with actual Apple Calendar API calls
    console.log('Mock Apple Calendar fetchEvents', { connection, timeMin, timeMax });
    return [];
  }

  async addEvent(connection: CalendarConnection, event: Omit<Event, 'id'>): Promise<Event> {
    // Mock implementation - replace with actual Apple Calendar API calls
    console.log('Mock Apple Calendar addEvent', { connection, event });
    return {
      id: `apple-${Date.now()}`,
      ...event
    };
  }
}

// Outlook Calendar Provider (Mock Implementation)
class OutlookCalendarProvider implements CalendarProvider {
  async fetchEvents(connection: CalendarConnection, timeMin: Date, timeMax: Date): Promise<Event[]> {
    // Mock implementation - replace with actual Microsoft Graph API calls
    console.log('Mock Outlook Calendar fetchEvents', { connection, timeMin, timeMax });
    return [];
  }

  async addEvent(connection: CalendarConnection, event: Omit<Event, 'id'>): Promise<Event> {
    // Mock implementation - replace with actual Microsoft Graph API calls
    console.log('Mock Outlook Calendar addEvent', { connection, event });
    return {
      id: `outlook-${Date.now()}`,
      ...event
    };
  }
}

const providers: Record<string, CalendarProvider> = {
  google: new GoogleCalendarProvider(),
  apple: new AppleCalendarProvider(),
  outlook: new OutlookCalendarProvider()
};

function detectEventType(event: any): 'work' | 'social' | 'personal' {
  const title = (event.summary || '').toLowerCase();
  const description = (event.description || '').toLowerCase();

  if (title.includes('meeting') || title.includes('work') || title.includes('conference')) {
    return 'work';
  } else if (title.includes('party') || title.includes('lunch') || title.includes('dinner')) {
    return 'social';
  }
  return 'personal';
}

export async function fetchCalendarEvents(connection: CalendarConnection, timeMin: Date, timeMax: Date): Promise<Event[]> {
  const provider = providers[connection.provider];
  if (!provider) {
    throw new Error(`Provider ${connection.provider} not supported`);
  }
  return provider.fetchEvents(connection, timeMin, timeMax);
}

export async function addEventToCalendar(connection: CalendarConnection, event: Omit<Event, 'id'>): Promise<Event> {
  const provider = providers[connection.provider];
  if (!provider) {
    throw new Error(`Provider ${connection.provider} not supported`);
  }
  return provider.addEvent(connection, event);
}

export async function syncCalendars(userId: number) {
  const connections = await db.query.calendarConnections.findMany({
    where: eq(calendarConnections.userId, userId)
  });

  const now = new Date();
  const oneWeekLater = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

  for (const conn of connections) {
    if (!conn.syncEnabled) continue;

    try {
      const events = await fetchCalendarEvents(conn, now, oneWeekLater);
      await updateLastSynced(conn.id);
    } catch (error) {
      console.error(`Failed to sync calendar ${conn.id}:`, error);
    }
  }
}

async function updateLastSynced(connectionId: number) {
  await db.update(calendarConnections)
    .set({ lastSynced: new Date() })
    .where(eq(calendarConnections.id, connectionId));
}