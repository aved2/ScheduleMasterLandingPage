
import { getRecommendationsBetweenEvents } from '../yelp-service';

describe('Yelp Service', () => {
  it('should get recommendations between events', async () => {
    const location = "San Francisco";
    const startTime = new Date('2025-01-25T11:00:00');
    const endTime = new Date('2025-01-25T13:00:00');

    const recommendations = await getRecommendationsBetweenEvents(location, startTime, endTime, {
      radius: 1500,
      maxResults: 5,
      includeRestaurants: true
    });

    expect(recommendations).toBeDefined();
    expect(Array.isArray(recommendations.restaurants)).toBe(true);
    expect(Array.isArray(recommendations.activities)).toBe(true);

    // Check restaurant properties
    if (recommendations.restaurants.length > 0) {
      const restaurant = recommendations.restaurants[0];
      expect(restaurant).toHaveProperty('id');
      expect(restaurant).toHaveProperty('name');
      expect(restaurant).toHaveProperty('rating');
      expect(restaurant).toHaveProperty('location');
    }

    // Check activity properties
    if (recommendations.activities.length > 0) {
      const activity = recommendations.activities[0];
      expect(activity).toHaveProperty('id');
      expect(activity).toHaveProperty('name');
      expect(activity).toHaveProperty('categories');
    }
  });
});
