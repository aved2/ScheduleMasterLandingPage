
import dotenv from 'dotenv';

dotenv.config();

// Ensure required env vars are set for tests
if (!process.env.YELP_API_KEY) {
  throw new Error('YELP_API_KEY environment variable is required for tests');
}
