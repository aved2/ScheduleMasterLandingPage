interface WeatherForecast {
  temp: number;      // Temperature in Celsius
  condition: string; // Weather condition description
}

export async function getWeatherForecast(location: string, date: Date): Promise<WeatherForecast> {
  try {
    // OpenWeatherMap API endpoint
    const geocodeUrl = `http://api.openweathermap.org/geo/1.0/direct?q=${encodeURIComponent(location)}&limit=1&appid=${process.env.OPENWEATHER_API_KEY}`;
    
    // Get coordinates for the location
    const geocodeResponse = await fetch(geocodeUrl);
    const [locationData] = await geocodeResponse.json();
    
    if (!locationData) {
      throw new Error('Location not found');
    }

    const { lat, lon } = locationData;
    
    // Get weather forecast
    const weatherUrl = `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&units=metric&appid=${process.env.OPENWEATHER_API_KEY}`;
    const weatherResponse = await fetch(weatherUrl);
    const weatherData = await weatherResponse.json();

    // Find the forecast closest to the event time
    const targetTime = date.getTime();
    const closestForecast = weatherData.list.reduce((closest: any, current: any) => {
      const currentTime = new Date(current.dt * 1000).getTime();
      const closestTime = new Date(closest.dt * 1000).getTime();
      
      return Math.abs(currentTime - targetTime) < Math.abs(closestTime - targetTime)
        ? current
        : closest;
    });

    return {
      temp: closestForecast.main.temp,
      condition: closestForecast.weather[0].description
    };
  } catch (error) {
    console.error('Weather forecast error:', error);
    // Return default values if weather service fails
    return {
      temp: 20, // Assume moderate temperature
      condition: 'clear'
    };
  }
}
