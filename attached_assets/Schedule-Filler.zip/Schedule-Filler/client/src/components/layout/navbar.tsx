import { Link } from "wouter";
import { Calendar, Settings, Menu, X, Star, Info, Map } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";

export default function Navbar() {
  const items = [
    { name: "Features", href: "/features", icon: Calendar },
    { name: "Testimonials", href: "/testimonials", icon: Star },
    { name: "Product Info", href: "/product-info", icon: Info },
    { name: "Roadmap", href: "/roadmap", icon: Map },
  ];
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };

    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  return (
    <header className="fixed top-0 left-0 right-0 border-b bg-card/80 backdrop-blur-sm z-50">
      <nav className="container mx-auto px-4">
        <div className="h-16 flex items-center justify-between">
          <Link href="/">
            <div className="flex items-center gap-3">
              <Calendar className="h-7 w-7" />
              <span className="font-semibold text-xl">ActivitySync</span>
            </div>
          </Link>

          {isMobile ? (
            <>
              <Button 
                variant="ghost" 
                size="lg" 
                onClick={toggleMenu}
                className="p-2"
              >
                {isMenuOpen ? (
                  <X className="h-7 w-7" />
                ) : (
                  <Menu className="h-7 w-7" />
                )}
              </Button>
              <div className={`${isMenuOpen ? 'block' : 'hidden'} md:hidden fixed top-16 left-0 right-0 bg-card border-b p-4 shadow-lg z-50`}>
                <nav className="flex flex-col space-y-2">
                  {items.map(item => {
                    const Icon = item.icon;
                    return (
                      <Link key={item.href} href={item.href}>
                        <Button variant="ghost" className="w-full justify-start gap-3 py-4 text-lg" onClick={() => setIsMenuOpen(false)}>
                          <Icon className="h-5 w-5" />
                          {item.name}
                        </Button>
                      </Link>
                    );
                  })}
                  <Link href="/settings">
                    <Button variant="ghost" className="w-full justify-start gap-3 py-4 text-lg" onClick={() => setIsMenuOpen(false)}>
                      <Settings className="h-5 w-5" />
                      Settings
                    </Button>
                  </Link>
                </nav>
              </div>
            </>
          ) : (
            <div className="flex items-center gap-4">
              {items.map(item => {
                const Icon = item.icon;
                return (
                  <Link key={item.href} href={item.href}>
                    <Button variant="ghost" className="gap-2">
                      <Icon className="h-5 w-5" />
                      {item.name}
                    </Button>
                  </Link>
                );
              })}
              <Link href="/settings">
                <Button variant="ghost" className="gap-2">
                  <Settings className="h-5 w-5" />
                  Settings
                </Button>
              </Link>
            </div>
          )}
        </div>
      </nav>
    </header>
  );
}