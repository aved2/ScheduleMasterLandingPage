import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import type { SharedEvent } from "@db/schema";

interface EventResponseDialogProps {
  event: SharedEvent;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function EventResponseDialog({ event, open, onOpenChange }: EventResponseDialogProps) {
  const [notes, setNotes] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const respondMutation = useMutation({
    mutationFn: async (status: 'accepted' | 'declined') => {
      const response = await fetch(`/api/events/${event.id}/respond`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status, notes }),
      });
      if (!response.ok) {
        throw new Error("Failed to respond to event");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/groups/${event.groupId}/events`] });
      toast({
        title: "Response sent",
        description: "Your response has been recorded.",
      });
      onOpenChange(false);
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to send response. Please try again.",
      });
    },
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Respond to Event: {event.title}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-2 block">Add a note (optional)</label>
            <Textarea
              placeholder="Add any comments or notes..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="resize-none"
            />
          </div>
          <div className="flex justify-end gap-2">
            <Button
              variant="outline"
              onClick={() => respondMutation.mutate('declined')}
              disabled={respondMutation.isPending}
            >
              Decline
            </Button>
            <Button
              onClick={() => respondMutation.mutate('accepted')}
              disabled={respondMutation.isPending}
            >
              Accept
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
