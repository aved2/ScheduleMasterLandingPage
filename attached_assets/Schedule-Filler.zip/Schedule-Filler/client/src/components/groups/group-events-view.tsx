import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, MapPin, Users, Star, AlertTriangle, AlertCircle } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import type { SharedEvent } from "@db/schema";
import { format } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface GroupEventsViewProps {
  groupId: number;
}

interface ConflictInfo {
  event: SharedEvent;
  overlapPercentage: number;
}

interface ConflictResponse {
  conflicts: ConflictInfo[];
  suggestedTimes: string[];
}

export default function GroupEventsView({ groupId }: GroupEventsViewProps) {
  const [selectedEventId, setSelectedEventId] = useState<number | null>(null);

  const { data: events = [] } = useQuery<SharedEvent[]>({
    queryKey: [`/api/groups/${groupId}/events`],
  });

  const { data: conflictData } = useQuery<ConflictResponse>({
    queryKey: [`/api/events/${selectedEventId}/conflicts`],
    enabled: !!selectedEventId,
  });

  const getPriorityColor = (score: number) => {
    if (score >= 80) return "text-red-500";
    if (score >= 60) return "text-orange-500";
    if (score >= 40) return "text-yellow-500";
    return "text-green-500";
  };

  const getPriorityLabel = (score: number) => {
    if (score >= 80) return "Critical";
    if (score >= 60) return "High";
    if (score >= 40) return "Medium";
    return "Low";
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Group Events</h2>
        <Button className="gap-2">
          <Calendar className="h-4 w-4" />
          Create Event
        </Button>
      </div>

      {events.length === 0 ? (
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground">
              No events scheduled yet. Create one to get started!
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {events.map((event) => (
            <Card key={event.id} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center gap-2">
                      <CardTitle>{event.title}</CardTitle>
                      {event.priorityScore >= 80 && (
                        <AlertTriangle className="h-5 w-5 text-red-500" />
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      {event.description}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Dialog open={selectedEventId === event.id} onOpenChange={(open) => setSelectedEventId(open ? event.id : null)}>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm" className="gap-2">
                          <AlertCircle className="h-4 w-4" />
                          Check Conflicts
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Event Conflicts</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          {conflictData?.conflicts.length === 0 ? (
                            <p className="text-sm text-muted-foreground">
                              No conflicts found for this event.
                            </p>
                          ) : (
                            <>
                              <div className="space-y-3">
                                <h3 className="font-medium">Conflicting Events:</h3>
                                {conflictData?.conflicts.map((conflict) => (
                                  <div key={conflict.event.id} className="p-3 bg-red-50 rounded-md">
                                    <div className="font-medium">{conflict.event.title}</div>
                                    <div className="text-sm text-muted-foreground">
                                      {format(new Date(conflict.event.startTime), "PPp")}
                                    </div>
                                    <div className="text-sm text-red-600">
                                      {Math.round(conflict.overlapPercentage * 100)}% overlap
                                    </div>
                                  </div>
                                ))}
                              </div>
                              {conflictData?.suggestedTimes.length > 0 && (
                                <div className="space-y-3">
                                  <h3 className="font-medium">Suggested Alternative Times:</h3>
                                  {conflictData.suggestedTimes.map((time, index) => (
                                    <Button
                                      key={index}
                                      variant="outline"
                                      className="w-full justify-start"
                                      onClick={() => {
                                        // TODO: Implement rescheduling
                                      }}
                                    >
                                      {format(new Date(time), "PPp")}
                                    </Button>
                                  ))}
                                </div>
                              )}
                            </>
                          )}
                        </div>
                      </DialogContent>
                    </Dialog>
                    <Button variant="outline" size="sm">
                      Respond
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    <span>
                      {format(new Date(event.startTime), "PPP p")} -{" "}
                      {format(new Date(event.endTime), "p")}
                    </span>
                  </div>
                  {event.location && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      <span>{event.location}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Users className="h-4 w-4" />
                    <span>
                      {event.participants?.length || 0} participants
                    </span>
                  </div>

                  {/* Priority and Importance Scores */}
                  <div className="space-y-2 pt-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Priority</span>
                      <span className={`text-sm font-medium ${getPriorityColor(Number(event.priorityScore) || 0)}`}>
                        {getPriorityLabel(Number(event.priorityScore) || 0)}
                      </span>
                    </div>
                    <Progress 
                      value={Number(event.priorityScore) || 0} 
                      className="h-2"
                    />

                    <div className="flex items-center justify-between mt-2">
                      <span className="text-sm font-medium">Importance</span>
                      <span className="text-sm font-medium">
                        {Math.round(Number(event.importanceScore) || 0)}%
                      </span>
                    </div>
                    <Progress 
                      value={Number(event.importanceScore) || 0} 
                      className="h-2"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}