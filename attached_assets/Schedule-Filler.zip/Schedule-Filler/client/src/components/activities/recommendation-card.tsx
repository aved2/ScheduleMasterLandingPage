import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Star, MapPin, Clock } from "lucide-react";
import { format } from "date-fns";

interface YelpBusiness {
  id: string;
  name: string;
  url: string;
  rating: number;
  price?: string;
  categories: Array<{ alias: string; title: string }>;
  location: {
    address1: string;
    city: string;
    state: string;
    country: string;
  };
}

interface EventRecommendations {
  eventId: string;
  eventTitle: string;
  eventStart: string;
  eventEnd: string;
  location: string;
  recommendations: {
    restaurants: YelpBusiness[];
    activities: YelpBusiness[];
  };
}

interface RecommendationCardProps {
  recommendation: EventRecommendations;
}

export default function RecommendationCard({ recommendation }: RecommendationCardProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">
          Recommendations for {recommendation.eventTitle}
        </CardTitle>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Clock className="h-4 w-4" />
          {format(new Date(recommendation.eventStart), 'MMM d, h:mm a')}
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <MapPin className="h-4 w-4" />
          {recommendation.location}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <h3 className="font-medium mb-2">Nearby Restaurants</h3>
            <div className="space-y-2">
              {recommendation.recommendations.restaurants.map((restaurant) => (
                <a
                  key={restaurant.id}
                  href={restaurant.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block p-3 rounded-lg border hover:bg-accent"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{restaurant.name}</span>
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm">{restaurant.rating}</span>
                      {restaurant.price && (
                        <span className="text-sm text-muted-foreground ml-2">
                          {restaurant.price}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">
                    {restaurant.location.address1}
                  </div>
                </a>
              ))}
            </div>
          </div>

          <div>
            <h3 className="font-medium mb-2">Nearby Activities</h3>
            <div className="space-y-2">
              {recommendation.recommendations.activities.map((activity) => (
                <a
                  key={activity.id}
                  href={activity.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block p-3 rounded-lg border hover:bg-accent"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{activity.name}</span>
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm">{activity.rating}</span>
                    </div>
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">
                    {activity.categories.map(c => c.title).join(", ")}
                  </div>
                </a>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
