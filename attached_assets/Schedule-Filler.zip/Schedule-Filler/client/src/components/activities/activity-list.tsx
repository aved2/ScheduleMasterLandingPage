import { useToast } from "@/hooks/use-toast";
import SuggestionCard from "./suggestion-card";
import type { Activity } from "@db/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";

interface ActivityListProps {
  activities: Activity[];
}

export default function ActivityList({ activities }: ActivityListProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const acceptMutation = useMutation({
    mutationFn: async (activityId: number) => {
      const response = await fetch("/api/activities/preferences", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ activityId, preferred: true }),
      });
      if (!response.ok) {
        throw new Error('Failed to accept activity');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      toast({
        title: "Activity accepted",
        description: "We'll keep this in mind for future suggestions",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to accept activity. Please try again.",
      });
    }
  });

  const declineMutation = useMutation({
    mutationFn: async (activityId: number) => {
      const response = await fetch("/api/activities/preferences", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ activityId, preferred: false }),
      });
      if (!response.ok) {
        throw new Error('Failed to decline activity');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      toast({
        title: "Activity declined",
        description: "We'll suggest something else next time",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to decline activity. Please try again.",
      });
    }
  });

  return (
    <div className="space-y-4">
      {activities.map((activity) => (
        <SuggestionCard
          key={activity.id}
          activity={activity}
          onAccept={() => acceptMutation.mutate(activity.id)}
          onDecline={() => declineMutation.mutate(activity.id)}
        />
      ))}
    </div>
  );
}