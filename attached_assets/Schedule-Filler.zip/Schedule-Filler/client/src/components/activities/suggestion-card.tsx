import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Clock, MapPin } from "lucide-react";
import type { Activity } from "@db/schema";

interface SuggestionCardProps {
  activity: Activity;
  onAccept: () => void;
  onDecline: () => void;
}

export default function SuggestionCard({ activity, onAccept, onDecline }: SuggestionCardProps) {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader>
        <CardTitle className="text-lg">{activity.name}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activity.imageUrl && (
            <img
              src={activity.imageUrl}
              alt={activity.name}
              className="w-full h-48 object-cover rounded-md"
            />
          )}

          <p className="text-sm text-muted-foreground">
            {activity.description}
          </p>

          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              {activity.durationMinutes} mins
            </div>
            <div className="flex items-center gap-1">
              <MapPin className="h-4 w-4" />
              {activity.type}
            </div>
          </div>

          <div className="flex gap-2">
            <Button
              onClick={onAccept}
              className="flex-1"
            >
              Accept
            </Button>
            <Button
              variant="outline"
              onClick={onDecline}
              className="flex-1"
            >
              Decline
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}