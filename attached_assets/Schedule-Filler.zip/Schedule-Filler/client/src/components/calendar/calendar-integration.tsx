import { Button } from "@/components/ui/button";
import { SiGoogle, SiApple } from "react-icons/si";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Calendar, Mail } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface CalendarProvider {
  id: string;
  name: string;
  icon: any; // Using any type since we're mixing libraries
  color: string;
}

const providers: CalendarProvider[] = [
  {
    id: 'google',
    name: 'Google Calendar',
    icon: SiGoogle,
    color: 'text-red-500'
  },
  {
    id: 'apple',
    name: 'Apple Calendar',
    icon: SiApple,
    color: 'text-gray-700'
  },
  {
    id: 'outlook',
    name: 'Outlook Calendar',
    icon: Mail, // Using Lucide React's Mail icon instead
    color: 'text-blue-500'
  }
];

export default function CalendarIntegration() {
  const { toast } = useToast();

  const handleCalendarAuth = async (providerId: string) => {
    try {
      const width = 600;
      const height = 700;
      const left = window.screenX + (window.outerWidth - width) / 2;
      const top = window.screenY + (window.outerHeight - height) / 2;

      const BASE_URL = `https://${window.location.hostname}`;
      const popup = window.open(
        `${BASE_URL}/api/auth/${providerId}/calendar`,
        `${providerId} Calendar Authorization`,
        `width=${width},height=${height},left=${left},top=${top},popup=1`
      );

      if (!popup) {
        toast({
          variant: "destructive",
          title: "Popup Blocked",
          description: "Please allow popups for this site to connect your calendar.",
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Connection Error",
        description: "Unable to connect to calendar. Please try again.",
      });
    }
  };

  return (
    <div className="flex flex-col items-center gap-6 p-4">
      <Card className="w-full max-w-md">
        <CardContent className="pt-6">
          <div className="flex items-center gap-3 mb-4">
            <Calendar className="h-5 w-5 text-blue-500" />
            <h2 className="text-lg font-semibold">Connect Calendar</h2>
          </div>

          <Alert className="mb-4">
            <Calendar className="h-4 w-4" />
            <AlertDescription>
              Connect your calendars to get personalized activity recommendations
              based on your schedule.
            </AlertDescription>
          </Alert>

          <div className="space-y-3">
            {providers.map((provider) => {
              const Icon = provider.icon;
              return (
                <Button
                  key={provider.id}
                  size="lg"
                  className="flex items-center gap-3 w-full"
                  onClick={() => handleCalendarAuth(provider.id)}
                >
                  <Icon className={`h-5 w-5 ${provider.color}`} />
                  Connect {provider.name}
                </Button>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}