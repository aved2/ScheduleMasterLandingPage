
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

interface MeetingEndDialogProps {
  isOpen: boolean;
  onClose: () => void;
  location?: string;
}

export function MeetingEndDialog({ isOpen, onClose, location }: MeetingEndDialogProps) {
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const handleOptionClick = (option: string) => {
    const searchParams = location ? `?location=${encodeURIComponent(location)}` : '';
    setLocation(`/recommendations/${option.toLowerCase()}${searchParams}`);
    toast({
      title: "Searching for recommendations",
      description: `Looking for ${option.toLowerCase()} options nearby...`
    });
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>What would you like to do next?</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-3 gap-4">
          <Button onClick={() => handleOptionClick('Food')}>Find Food</Button>
          <Button onClick={() => handleOptionClick('Activities')}>Activities</Button>
          <Button onClick={() => handleOptionClick('Shopping')}>Shopping</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
