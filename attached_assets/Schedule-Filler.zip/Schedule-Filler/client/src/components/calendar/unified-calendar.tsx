import { Calendar } from "@/components/ui/calendar";
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import type { CalendarConnection } from "@db/schema";
import { MeetingEndDialog } from "./meeting-end-dialog"; // Added import


interface UnifiedCalendarProps {
  connections: CalendarConnection[];
  events: any[]; // Added events prop.  Type needs clarification based on actual event data.
}

export default function UnifiedCalendar({ connections, events }: UnifiedCalendarProps) { // Added events to props
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [showEndDialog, setShowEndDialog] = useState(false);
  const [lastEventLocation, setLastEventLocation] = useState<string>();

  useEffect(() => {
    const checkMeetingEnd = () => {
      const now = new Date();
      events.forEach(event => {
        const endTime = new Date(event.end);
        const timeDiff = endTime.getTime() - now.getTime();

        // Show dialog when meeting ends (within last minute)
        if (timeDiff >= 0 && timeDiff <= 60000) {
          setLastEventLocation(event.location);
          setShowEndDialog(true);
        }
      });
    };

    const interval = setInterval(checkMeetingEnd, 600000); // Check every 10 minutes
    return () => clearInterval(interval);
  }, [events]);

  return (
    <div className="p-4">
      <MeetingEndDialog 
        isOpen={showEndDialog}
        onClose={() => setShowEndDialog(false)}
        location={lastEventLocation}
      />
      <Calendar
        mode="single"
        selected={date}
        onSelect={setDate}
        className="rounded-md border"
        classNames={{
          day_selected: "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground focus:bg-primary focus:text-primary-foreground",
          day_today: "bg-accent text-accent-foreground",
        }}
      />

      <div className="mt-4 space-y-2">
        {connections.map((connection) => (
          <div
            key={connection.id}
            className="flex items-center gap-2"
          >
            <div
              className="w-3 h-3 rounded-full"
              style={{ backgroundColor: connection.color }}
            />
            <span className="text-sm text-muted-foreground">
              {connection.provider} Calendar
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}