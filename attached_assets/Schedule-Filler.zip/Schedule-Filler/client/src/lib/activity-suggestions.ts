import type { Activity, UserActivity } from "@db/schema";
import { getDayPeriod, type CalendarEvent } from "./calendar-utils";

interface SuggestionContext {
  freeTimeSlot: {
    start: Date;
    end: Date;
  };
  weatherConditions?: {
    isGoodWeather: boolean;
    temperature: number;
  };
  userPreferences: UserActivity[];
}

export function rankActivities(
  activities: Activity[],
  context: SuggestionContext
): Activity[] {
  const {
    freeTimeSlot,
    weatherConditions = { isGoodWeather: true, temperature: 20 },
    userPreferences
  } = context;

  const slotDuration = (freeTimeSlot.end.getTime() - freeTimeSlot.start.getTime()) / (60 * 1000);
  const timeOfDay = getDayPeriod(freeTimeSlot.start);

  return activities
    .filter(activity => {
      // Filter out activities that don't fit the time slot
      if (activity.durationMinutes > slotDuration) return false;

      // Filter out weather-dependent outdoor activities in bad weather
      if (activity.weatherDependent && !weatherConditions.isGoodWeather) return false;

      // Filter activities by time of day preference
      if (activity.timeOfDay && !activity.timeOfDay.includes(timeOfDay)) return false;

      return true;
    })
    .map(activity => {
      let score = 0;

      // Preferred activities get a boost
      const preference = userPreferences.find(p => p.activityId === activity.id);
      if (preference?.preferred) score += 5;

      // Activities that better fit the time slot get a boost
      const fitScore = 1 - Math.abs(slotDuration - activity.durationMinutes) / slotDuration;
      score += fitScore * 3;

      // Outdoor activities get a boost in good weather
      if (activity.type === "outdoor" && weatherConditions.isGoodWeather) {
        score += 2;
      }

      // Indoor activities get a boost in bad weather
      if (activity.type === "indoor" && !weatherConditions.isGoodWeather) {
        score += 2;
      }

      return { ...activity, score };
    })
    .sort((a, b) => (b as any).score - (a as any).score)
    .map(({ score, ...activity }) => activity);
}

export function generateSuggestions(
  activities: Activity[],
  events: CalendarEvent[],
  userPreferences: UserActivity[],
  count: number = 3
): Activity[] {
  // Mock weather data - in a real app, this would come from a weather API
  const mockWeather = {
    isGoodWeather: true,
    temperature: 22
  };

  // Find the first available time slot
  const now = new Date();
  const nextSlot = {
    start: new Date(now.getTime() + 60 * 60 * 1000), // 1 hour from now
    end: new Date(now.getTime() + 3 * 60 * 60 * 1000), // 3 hours from now
  };

  const context: SuggestionContext = {
    freeTimeSlot: nextSlot,
    weatherConditions: mockWeather,
    userPreferences
  };

  const rankedActivities = rankActivities(activities, context);
  return rankedActivities.slice(0, count);
}

export const activityImages = {
  hiking: "https://images.unsplash.com/photo-1551632811-561732d1e306",
  camping: "https://images.unsplash.com/photo-1504280390367-361c6d9f38f4",
  cycling: "https://images.unsplash.com/photo-1541625602330-2277a4c46182",
  reading: "https://images.unsplash.com/photo-1513001900722-370f803f498d",
  cooking: "https://images.unsplash.com/photo-1556911220-e15b29be8c8f",
  gaming: "https://images.unsplash.com/photo-1511512578047-dfb367046420"
};