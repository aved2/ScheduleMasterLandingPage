import type { CalendarConnection } from "@db/schema";

export interface CalendarEvent {
  id: string;
  title: string;
  start: Date;
  end: Date;
  calendarId: string;
  color?: string;
}

interface TimeSlot {
  start: Date;
  end: Date;
}

export function mergeCalendarEvents(connections: CalendarConnection[], events: CalendarEvent[][]): CalendarEvent[] {
  const mergedEvents: CalendarEvent[] = [];
  
  events.forEach((calendarEvents, index) => {
    const connection = connections[index];
    calendarEvents.forEach(event => {
      mergedEvents.push({
        ...event,
        color: connection.color
      });
    });
  });
  
  return mergedEvents.sort((a, b) => a.start.getTime() - b.start.getTime());
}

export function findFreeTimeSlots(events: CalendarEvent[], minDuration: number): TimeSlot[] {
  const freeSlots: TimeSlot[] = [];
  const sortedEvents = [...events].sort((a, b) => a.start.getTime() - b.start.getTime());
  
  // Start searching from current time
  let currentTime = new Date();
  currentTime.setMinutes(Math.ceil(currentTime.getMinutes() / 30) * 30);
  currentTime.setSeconds(0);
  currentTime.setMilliseconds(0);
  
  // Look ahead 7 days maximum
  const endTime = new Date(currentTime.getTime() + 7 * 24 * 60 * 60 * 1000);
  
  let timePointer = currentTime;
  
  sortedEvents.forEach(event => {
    if (timePointer < event.start) {
      const gap = event.start.getTime() - timePointer.getTime();
      if (gap >= minDuration * 60 * 1000) {
        freeSlots.push({
          start: new Date(timePointer),
          end: new Date(event.start)
        });
      }
    }
    timePointer = new Date(Math.max(timePointer.getTime(), event.end.getTime()));
  });
  
  // Add final slot if there's time remaining
  if (timePointer < endTime) {
    freeSlots.push({
      start: new Date(timePointer),
      end: new Date(endTime)
    });
  }
  
  return freeSlots;
}

export function isBusinessHours(date: Date): boolean {
  const hours = date.getHours();
  return hours >= 9 && hours <= 17;
}

export function isDayTime(date: Date): boolean {
  const hours = date.getHours();
  return hours >= 8 && hours <= 20;
}

export function formatTimeRange(start: Date, end: Date): string {
  return `${start.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} - ${end.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
}

export function getDayPeriod(date: Date): "morning" | "afternoon" | "evening" {
  const hours = date.getHours();
  if (hours >= 5 && hours < 12) return "morning";
  if (hours >= 12 && hours < 17) return "afternoon";
  return "evening";
}
