import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";

const plans = [
  {
    name: "Basic",
    price: "Free",
    description: "Perfect for individuals",
    features: [
      "Connect up to 2 calendars",
      "Basic AI suggestions",
      "7-day event history",
      "Standard support"
    ]
  },
  {
    name: "Pro",
    price: "$9.99/month",
    description: "Ideal for professionals",
    features: [
      "Connect unlimited calendars",
      "Advanced AI suggestions",
      "30-day event history",
      "Priority support",
      "Offline access",
      "Custom integrations"
    ]
  },
  {
    name: "Team",
    price: "$19.99/user/month",
    description: "Perfect for organizations",
    features: [
      "All Pro features",
      "Team calendar management",
      "Admin controls",
      "Analytics dashboard",
      "API access",
      "24/7 dedicated support"
    ]
  }
];

export default function ProductInfo() {
  return (
    <div className="container mx-auto px-4 py-20">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Choose Your Plan</h1>
        <p className="text-xl text-muted-foreground">
          Find the perfect ActivitySync plan for your needs
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
        {plans.map((plan, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">{plan.name}</CardTitle>
              <div className="mt-4">
                <span className="text-4xl font-bold">{plan.price}</span>
                {plan.price !== "Free" && <span className="text-muted-foreground">/month</span>}
              </div>
              <p className="text-muted-foreground mt-2">{plan.description}</p>
            </CardHeader>
            <CardContent>
              <ul className="space-y-4">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-center gap-2">
                    <Check className="h-5 w-5 text-primary" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              <Button className="w-full mt-6">Get Started</Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
