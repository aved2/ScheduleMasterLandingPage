import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { CalendarDays, Clock, MapPin, Zap } from "lucide-react";
import CalendarIntegration from "@/components/calendar/calendar-integration";
import type { Activity, CalendarConnection } from "@db/schema";
import ActivityList from "@/components/activities/activity-list";

const demoActivities: Activity[] = [
  {
    id: 1,
    name: "Morning Yoga",
    description: "Start your day with energizing yoga flows",
    type: "fitness",
    durationMinutes: 60,
    weatherDependent: false,
    timeOfDay: ["morning"],
    location: null,
    imageUrl: null
  },
  {
    id: 2,
    name: "Park Run",
    description: "Enjoy a refreshing run in the park",
    type: "outdoor",
    durationMinutes: 45,
    weatherDependent: true,
    timeOfDay: ["morning", "evening"],
    location: null,
    imageUrl: null
  },
  {
    id: 3,
    name: "Museum Visit",
    description: "Explore art and history at local museums",
    type: "cultural",
    durationMinutes: 120,
    weatherDependent: false,
    timeOfDay: ["afternoon"],
    location: null,
    imageUrl: null
  },
];

export default function Dashboard() {
  const { data: calendarConnections = [] } = useQuery<CalendarConnection[]>({
    queryKey: ["/api/calendar-connections"],
  });

  return (
    <div className="max-w-7xl mx-auto px-4">
      {/* Hero Section */}
      <div className="py-20 text-center">
        <h1 className="text-5xl font-bold mb-6">Sync Your Life, Master Your Time</h1>
        <p className="text-xl text-muted-foreground mb-8">
          Your AI-powered calendar assistant for seamless schedule optimization
        </p>
        <div className="max-w-2xl mx-auto mb-12 grid grid-cols-3 gap-6">
          <div className="text-center">
            <h3 className="font-semibold mb-2">Smart Scheduling</h3>
            <p className="text-sm text-muted-foreground">AI-powered time slots for optimal productivity</p>
          </div>
          <div className="text-center">
            <h3 className="font-semibold mb-2">Activity Discovery</h3>
            <p className="text-sm text-muted-foreground">Personalized recommendations based on your free time</p>
          </div>
          <div className="text-center">
            <h3 className="font-semibold mb-2">Multi-Calendar Sync</h3>
            <p className="text-sm text-muted-foreground">Seamlessly integrate all your calendars</p>
          </div>
        </div>
      </div>

      {/* Calendar Integration Section */}
      <div className="mb-16">
        <CalendarIntegration />
      </div>

      {/* Features Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
        <Card>
          <CardContent className="pt-6">
            <div className="mb-4">
              <CalendarDays className="h-12 w-12 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Smart Calendar Integration</h3>
            <p className="text-muted-foreground">
              Connect multiple calendars and manage everything in one place
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="mb-4">
              <Zap className="h-12 w-12 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-2">AI-Powered Suggestions</h3>
            <p className="text-muted-foreground">
              Get personalized activity recommendations based on your schedule
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="mb-4">
              <MapPin className="h-12 w-12 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Local Discovery</h3>
            <p className="text-muted-foreground">
              Find activities and venues that fit perfectly into your day
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Connected Calendars Preview */}
      <Card className="mb-16">
        <CardHeader>
          <CardTitle>Your Connected Calendars</CardTitle>
        </CardHeader>
        <CardContent>
          {calendarConnections.length > 0 ? (
            <div className="space-y-4">
              {calendarConnections.map((connection) => (
                <div key={connection.id} className="flex items-center gap-4">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: connection.color }} />
                  <span>{connection.provider} Calendar</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground">No calendars connected yet. Connect your first calendar to get started!</p>
          )}
        </CardContent>
      </Card>

      {/* Activities Preview */}
      <Card className="mb-16">
        <CardHeader>
          <CardTitle>Smart Activity Suggestions</CardTitle>
        </CardHeader>
        <CardContent>
          <ActivityList activities={demoActivities} />
        </CardContent>
      </Card>

      {/* CTA Section */}
      <div className="text-center py-20">
        <h2 className="text-3xl font-bold mb-4">Ready to Optimize Your Time?</h2>
        <p className="text-xl text-muted-foreground mb-8">
          Join thousands of users who have transformed their daily scheduling
        </p>
        <Button size="lg" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          Get Started
        </Button>
      </div>
    </div>
  );
}