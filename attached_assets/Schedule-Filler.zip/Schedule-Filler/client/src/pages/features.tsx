import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar, Users, Zap, Globe, Clock, Lock } from "lucide-react";

const features = [
  {
    icon: Calendar,
    title: "Smart Calendar Integration",
    description: "Seamlessly sync with Google, Apple, and Outlook calendars to manage all your events in one place."
  },
  {
    icon: Users,
    title: "Social Scheduling",
    description: "Coordinate with friends and colleagues using group scheduling features and shared calendars."
  },
  {
    icon: Zap,
    title: "AI-Powered Suggestions",
    description: "Get intelligent activity recommendations based on your schedule and preferences."
  },
  {
    icon: Globe,
    title: "Multi-Language Support",
    description: "Use ActivitySync in your preferred language with our comprehensive localization."
  },
  {
    icon: Clock,
    title: "Offline Access",
    description: "Stay productive even without internet connection with our offline mode support."
  },
  {
    icon: Lock,
    title: "Secure Sync",
    description: "Your data is protected with enterprise-grade security and encryption."
  }
];

export default function Features() {
  return (
    <div className="container mx-auto px-4 py-20">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Features</h1>
        <p className="text-xl text-muted-foreground">
          Discover what makes ActivitySync the ultimate calendar solution
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {features.map((feature, index) => {
          const Icon = feature.icon;
          return (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <Icon className="h-12 w-12 mb-4 text-primary" />
                <CardTitle>{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
