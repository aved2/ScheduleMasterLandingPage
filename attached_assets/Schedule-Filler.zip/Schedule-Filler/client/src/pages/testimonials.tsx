import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Star } from "lucide-react";

const testimonials = [
  {
    name: "Sarah Johnson",
    role: "Project Manager",
    avatar: "https://i.pravatar.cc/150?u=sarah",
    quote: "ActivitySync has revolutionized how I manage my team's schedule. The AI suggestions are spot-on!",
    rating: 5
  },
  {
    name: "Michael Chen",
    role: "Freelance Designer",
    avatar: "https://i.pravatar.cc/150?u=michael",
    quote: "The multi-calendar integration is a game-changer. I can finally keep my work and personal life in sync.",
    rating: 5
  },
  {
    name: "Emily Rodriguez",
    role: "Small Business Owner",
    avatar: "https://i.pravatar.cc/150?u=emily",
    quote: "The offline mode ensures I never miss an appointment, even when traveling. Absolutely essential!",
    rating: 4
  }
];

export default function Testimonials() {
  return (
    <div className="container mx-auto px-4 py-20">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">What Our Users Say</h1>
        <p className="text-xl text-muted-foreground">
          Read how ActivitySync has transformed scheduling for professionals worldwide
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {testimonials.map((testimonial, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow">
            <CardHeader className="text-center">
              <Avatar className="h-20 w-20 mx-auto mb-4">
                <AvatarImage src={testimonial.avatar} alt={testimonial.name} />
                <AvatarFallback>{testimonial.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
              </Avatar>
              <CardTitle className="mb-2">{testimonial.name}</CardTitle>
              <p className="text-sm text-muted-foreground">{testimonial.role}</p>
              <div className="flex justify-center gap-1 mt-2">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-primary text-primary" />
                ))}
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-center italic">"{testimonial.quote}"</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
