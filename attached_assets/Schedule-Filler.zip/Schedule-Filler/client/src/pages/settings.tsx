import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import CalendarIntegration from "@/components/calendar/calendar-integration";
import type { CalendarConnection } from "@db/schema";

export default function Settings() {
  const { toast } = useToast();

  const { data: connections } = useQuery<CalendarConnection[]>({
    queryKey: ["/api/calendar-connections"],
  });

  return (
    <div className="max-w-md mx-auto py-8">
      <Card>
        <CardContent className="pt-6">
          <CalendarIntegration />

          {connections?.length > 0 && (
            <div className="mt-6 space-y-4">
              <h3 className="font-medium text-lg">Connected Calendars</h3>
              {connections.map((connection) => (
                <div
                  key={connection.id}
                  className="flex items-center gap-3 p-4 bg-accent/50 rounded-lg"
                >
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: connection.color }}
                  />
                  <span>{connection.provider} Calendar</span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}