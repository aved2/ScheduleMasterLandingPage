import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CalendarClock, Users, Globe, Smartphone, ChartBar, Trophy } from "lucide-react";

const roadmapItems = [
  {
    icon: CalendarClock,
    title: "Apple Calendar Integration",
    description: "Native integration with Apple Calendar for seamless iOS and macOS sync.",
    status: "In Progress",
    quarter: "Q1 2025"
  },
  {
    icon: Users,
    title: "Group Scheduling Enhancement",
    description: "Advanced group calendar features with conflict resolution and voting system.",
    status: "Planning",
    quarter: "Q2 2025"
  },
  {
    icon: Globe,
    title: "Multi-language Support",
    description: "Localization in 10+ languages with regional calendar preferences.",
    status: "Coming Soon",
    quarter: "Q2 2025"
  },
  {
    icon: Smartphone,
    title: "Mobile Apps",
    description: "Native mobile applications for iOS and Android platforms.",
    status: "In Development",
    quarter: "Q3 2025"
  },
  {
    icon: ChartBar,
    title: "Analytics Dashboard",
    description: "Comprehensive analytics for time management and productivity insights.",
    status: "Planning",
    quarter: "Q3 2025"
  },
  {
    icon: Trophy,
    title: "Gamification System",
    description: "Achievement system to encourage productive scheduling habits.",
    status: "Planned",
    quarter: "Q4 2025"
  }
];

export default function Roadmap() {
  return (
    <div className="container mx-auto px-4 py-20">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Product Roadmap</h1>
        <p className="text-xl text-muted-foreground">
          Discover what's coming next to ActivitySync
        </p>
      </div>

      <div className="max-w-4xl mx-auto space-y-6">
        {roadmapItems.map((item, index) => {
          const Icon = item.icon;
          return (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-4">
                    <Icon className="h-8 w-8 text-primary" />
                    <div>
                      <CardTitle className="text-xl">{item.title}</CardTitle>
                      <p className="text-sm text-muted-foreground mt-1">{item.description}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="inline-block px-3 py-1 rounded-full text-sm bg-primary/10 text-primary">
                      {item.status}
                    </span>
                    <p className="text-sm text-muted-foreground mt-1">{item.quarter}</p>
                  </div>
                </div>
              </CardHeader>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
